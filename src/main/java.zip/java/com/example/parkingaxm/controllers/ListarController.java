package com.example.parkingaxm.controllers;

public class ListarController {
    // Lógica del módulo correspondiente
}
