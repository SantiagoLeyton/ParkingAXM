package com.example.parkingaxm.enums;

public enum Rol {
    ADMIN,
    OPERARIO
}
