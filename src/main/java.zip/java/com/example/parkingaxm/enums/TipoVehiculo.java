package com.example.parkingaxm.enums;

/**
 * Tipo de vehículo que puede ingresar al parqueadero.
 */
public enum TipoVehiculo {
    CARRO,
    MOTO
}
